import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.*;

public class MyFrame extends JFrame {
    public MyFrame(Pole p) {
        super("Rysowanie");
        setSize(new Dimension(650,650));
        JPanel panel = new Rysuj(p);
        add(panel);
        pack();
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }
}
