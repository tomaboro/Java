import java.awt.*;

/**
 * Created by Tomek on 04.01.2017.
 */
public class Main {
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                Pole mapa = new Pole(65);
                new MyFrame(mapa);
            }
        });
    }
}
